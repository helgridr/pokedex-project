//
//  ListViewController.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/17/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import  UIKit

class ListViewController: UITableViewController {
    
    var pokemonList:[Pokemon]=[]
    var currentSelection:Int?
    var listUrl:String?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let url = listUrl else{return}
        ImprovedNetworking.callNetwork(type: .getSecondaryPokemonList(url)){
            [weak self](results,error) in
            guard error == nil else{return}
            guard let list = results as? [Pokemon] else{return}
            DispatchQueue.main.async {
                self?.pokemonList = list
                self?.tableView.reloadData()
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pokemonList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)->UITableViewCell{
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "ListCell") as? PokedexCell else{
            fatalError("BOOM!!! (went the cell)")
        }
        cell.layer.cornerRadius = 10
        cell.loadCell(name: pokemonList[indexPath.row].pokemonName, number: pokemonList[indexPath.row].pokemonNumber)
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        guard identifier == "ToDetailViewAgain" else {return}
        guard let nextView = segue.destination as? DetailViewController else {return}
        guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
        currentSelection = indexPath.row
        nextView.pokemon = pokemonList[indexPath.row]
        
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
}


