//
//  NetworkCall.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/14/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation

enum NetworkCall{
    case getPokemonList
    case getImage(Int)
    case getDetails(Int)
    case getSecondaryPokemonList(String)
    case getPokemonListFirstChunk
    case getPokemonListNext20(String)
    
    func getUrl()->String{
        switch self {
        case .getPokemonList:
            return Constants.kPokemonListURL
        case .getImage(let pokemonNumber):
            return Constants.kImageUrl + "\(pokemonNumber).png"
        case .getDetails(let pokemonNumber):
            return Constants.kDetailsUrl + "\(pokemonNumber)"
        case .getSecondaryPokemonList(let url):
            return url
        case .getPokemonListFirstChunk:
            return Constants.kPokemonListURLFirstChunk
        case .getPokemonListNext20(let url):
            return url
        }
    }
}
