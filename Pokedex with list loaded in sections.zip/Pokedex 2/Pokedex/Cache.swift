//
//  Cache.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/14/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import  UIKit

class Cache{
    static var shared = Cache()
    var imageCache = NSCache<NSString,UIImage>()
    var detailsCache = NSCache<NSString,NSArray>()
}
