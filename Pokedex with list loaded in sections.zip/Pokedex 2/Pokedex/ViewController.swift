//
//  ViewController.swift
//  Pokedex
//
//  Created by Mac on 9/1/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    var pokemonList:[Pokemon]=[]
    var currentSelection:Int?
    var nextChunkUrl:String?
    var loadingList = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ImprovedNetworking.callNetwork(type: .getPokemonListFirstChunk){
            [unowned self](results,error) in
            guard error == nil else{return}
            guard let myResults = results as? ([Pokemon],String?) else{return}
            self.nextChunkUrl = myResults.1
            //print(self.nextChunkUrl)
            let list = myResults.0
            DispatchQueue.main.async {
                self.pokemonList += list
                self.tableView.reloadData()
            }
            self.loadingList = false
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pokemonList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)->UITableViewCell{
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell") as? PokedexCell else{
            fatalError("BOOM!!! (went the cell)")
        }
        cell.layer.cornerRadius = 10
        cell.loadCell(name: pokemonList[indexPath.row].pokemonName, number: pokemonList[indexPath.row].pokemonNumber)
        return cell
    }

    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (scrollView.contentOffset.y >= (scrollView.contentSize.height - scrollView.frame.size.height) && loadingList == false){
            loadingList = true
            guard let nextUrl = nextChunkUrl else {return}
            ImprovedNetworking.callNetwork(type: .getPokemonListNext20(nextUrl)){
                [weak self](results,error) in
                guard error == nil else{return}
                guard let myResults = results as? ([Pokemon],String?) else{return}
                self?.nextChunkUrl = myResults.1
                let list = myResults.0
                DispatchQueue.main.async {
                    self?.pokemonList += list
                    self?.tableView.reloadData()
                }
                self?.loadingList = false
            }
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        guard identifier == "ToDetailView" else {return}
        guard let nextView = segue.destination as? DetailViewController else {return}
        guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
        currentSelection = indexPath.row
        nextView.pokemon = pokemonList[indexPath.row]
        //nextView.detailViewDelegate = self

        self.tableView.deselectRow(at: indexPath, animated: true)
    }

}

