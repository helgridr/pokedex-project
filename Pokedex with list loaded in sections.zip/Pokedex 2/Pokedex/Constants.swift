//
//  Constants.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/14/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
class Constants{
    static let kImageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other-sprites/official-artwork/"
    static let kPokemonListURL = "https://pokeapi.co/api/v2/pokemon/?limit=151"
    static let kDetailsUrl = "https://pokeapi.co/api/v2/pokemon/"
    static let kPokemonListURLFirstChunk = "https://pokeapi.co/api/v2/pokemon/"
}
