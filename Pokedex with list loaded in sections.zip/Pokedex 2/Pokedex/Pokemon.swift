//
//  Pokemon.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/13/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit
struct Pokemon{
    var pokemonName:String
    var pokemonNumber:Int

    init (name: String, number:Int){
        pokemonName = name
        pokemonNumber = number
    }
    
    //formats the number for display
    static func formatNumber(_ number:Int)->String{
        switch String(number).characters.count{
        case 1:
            return "00\(number)"
        case 2:
            return "0\(number)"
        default:
            return "\(number)"
        }
    }

}
