//
//  NetworkError.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/11/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation

enum NetworkError{
    case apiDidFailWithError(String)
    case apiRespondedWithMalformedHTTPResponse
    case apiRespondedWithAnHTTPFailureCode(Int)
    case apiFailedParsingJSON(String)
    case apiRespondedWithMalformedData
    case dataIsNotAnImage
    case apiFoundNoSpeciesUrl
    case apiFailedConvertingJSONToDictionary
    case apiFailedParsingDictionaries
    case apiFailedWithAFunnyUrl(String)
}

