//
//  DetailViewImageCell.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/16/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class DetailViewImageCell:UITableViewCell{
    @IBOutlet weak var pokemonImage:UIImageView!
    func loadCell(name:String,number:Int){
        if let image = Cache.shared.imageCache.object(forKey: name as NSString){
            self.pokemonImage.image = image
            self.pokemonImage.layer.cornerRadius = 10
        } else {
            self.pokemonImage.image = #imageLiteral(resourceName: "MissingNo.")
            self.pokemonImage.layer.cornerRadius = 10
            ImprovedNetworking.callNetwork(type: .getImage(number)) {
                [weak self](image, error) in
                guard error == nil else {return}
                guard let image = image as? UIImage else {return}
                Cache.shared.imageCache.setObject(image, forKey: name as NSString)
                DispatchQueue.main.async {
                    self?.pokemonImage.image = image
                    self?.pokemonImage.layer.cornerRadius = 10
                }
            }
        }
    }
}
