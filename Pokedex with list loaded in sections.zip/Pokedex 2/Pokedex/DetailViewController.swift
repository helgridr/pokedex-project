//
//  DetailViewController.swift
//  Pokedex
//
//  Created by Mac on 9/1/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController:UITableViewController{


    var pokemon:Pokemon?
    var myDescription:[[String]] = [["Loading..."]]

    override func viewDidLoad() {
        super.viewDidLoad()
        guard let name = pokemon?.pokemonName else{return}
        guard let number = pokemon?.pokemonNumber else{return}

        if let description = Cache.shared.detailsCache.object(forKey: name as NSString) as? [[String]]{
            self.myDescription = description
            self.tableView.reloadData()
        } else {
            ImprovedNetworking.callNetwork(type: .getDetails(number)) {
                [weak self](details, error) in
                guard error == nil else {
                    DispatchQueue.main.async {
                        self?.myDescription = [["Error Loading Details"]]
                    }
                    return
                }
                guard let description = details as? [[String]] else {return}
                Cache.shared.detailsCache.setObject(description as NSArray, forKey: name as NSString)
                DispatchQueue.main.async {
                    self?.myDescription = description
                    self?.tableView.reloadData()
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return myDescription.count + 2
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PokemonDetails.getNumberOfRowsInSection(data: myDescription, section: section)
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return PokemonDetails.getSectionHeaders(section:section)
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let name = pokemon?.pokemonName ?? "Not Found"
        let number = pokemon?.pokemonNumber ?? 0
        
        switch indexPath.section{
        case 0:
            guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "TitleCell") as? DetailViewTitleCell else {fatalError("Boom")}
            cell.loadCell(name: name, number: number)
            cell.isUserInteractionEnabled = false
            return cell
        case 1:
            guard let cell2 = self.tableView.dequeueReusableCell(withIdentifier: "ImageCell") as? DetailViewImageCell else {fatalError("Boom")}
            cell2.loadCell(name: name, number: number)
            cell2.isUserInteractionEnabled = false
            return cell2
        case 5:
            guard let cell4 = self.tableView.dequeueReusableCell(withIdentifier: "PreviousEvolutionCell") as? DetailViewDetailCell else {fatalError("Boom")}
            cell4.detail.text = myDescription[indexPath.section - 2][indexPath.row]
            cell4.detail.sizeToFit()
            if myDescription[indexPath.section - 2].count != 2{
                cell4.isUserInteractionEnabled = false
            }else{
                cell4.isUserInteractionEnabled = true
            }
            return cell4
        default:
           guard let cell3 = self.tableView.dequeueReusableCell(withIdentifier: "DetailCell") as? DetailViewDetailCell else {fatalError("Boom")}
            switch indexPath.section{
            case 3,4,8:
                cell3.detail.text = myDescription[indexPath.section - 2][(indexPath.row)*2]
                cell3.isUserInteractionEnabled = true
            case 11, 13...16:
                cell3.detail.text = myDescription[indexPath.section - 2][indexPath.row]
                cell3.isUserInteractionEnabled = true
            default:
                cell3.detail.text = myDescription[indexPath.section - 2][indexPath.row]
                cell3.isUserInteractionEnabled = false
            }
           cell3.detail.sizeToFit()
            return cell3
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        //guard identifier == "ToListViewAgain" else {return}
        guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
        switch identifier {
        case "ToListViewAgain":
            guard let nextView = segue.destination as? ListViewController else {return}
            nextView.listUrl = myDescription[indexPath.section-2][(indexPath.row)*2 + 1]
        case "ToPreviousEvolution":
            guard let nextView = segue.destination as? DetailViewController else {return}
            nextView.pokemon = Pokemon(name: myDescription[indexPath.section-2][0], number: Int(myDescription[indexPath.section-2][1]) ?? 0)
        default:
            return
        }

        self.tableView.deselectRow(at: indexPath, animated: true)
    }
}

