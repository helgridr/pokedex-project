//
//  DetailViewTitleCell.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/16/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class DetailViewTitleCell:UITableViewCell{
    @IBOutlet weak var pokemonNumber:UILabel!
    @IBOutlet weak var pokemonName:UILabel!
    
    func loadCell(name:String,number:Int){//,image:UIImageView?){
        self.pokemonName.text = name
        self.pokemonNumber.text = Pokemon.formatNumber(number)
        self.pokemonNumber.sizeToFit()
        self.pokemonName.sizeToFit()
    }
}
