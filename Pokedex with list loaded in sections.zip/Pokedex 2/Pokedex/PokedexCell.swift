//
//  PokedexCell.swift
//  Pokedex
//
//  Created by Mac on 9/4/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class PokedexCell:UITableViewCell{
    @IBOutlet weak var pokemonName:UILabel!
    @IBOutlet weak var pokemonNumber:UILabel!
    @IBOutlet weak var pokemonImage:UIImageView!
    
    func loadCell(name:String,number:Int){//,image:UIImageView?){
        self.pokemonName.text = name
        self.pokemonNumber.text = Pokemon.formatNumber(number)
        
        if let image = Cache.shared.imageCache.object(forKey: name as NSString){
            self.pokemonImage.image = image
            self.pokemonImage.layer.cornerRadius = 10
        } else {
            self.pokemonImage.image = #imageLiteral(resourceName: "MissingNo.")
            self.pokemonImage.layer.cornerRadius = 10
            ImprovedNetworking.callNetwork(type: .getImage(number)) {
                [weak self](image, error) in
                guard error == nil else {return}
                guard let image = image as? UIImage else {return}
                Cache.shared.imageCache.setObject(image, forKey: name as NSString)
                DispatchQueue.main.async {
                    self?.pokemonImage.image = image
                }
            }
        }
    }
}
