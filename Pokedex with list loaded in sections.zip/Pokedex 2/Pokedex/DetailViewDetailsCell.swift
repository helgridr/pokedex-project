//
//  DetailViewDetailsCell.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/16/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class DetailViewDetailCell:UITableViewCell{
    @IBOutlet weak var detail:UILabel!
}
