//
//  pokemonDetails.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

struct PokemonDetails{
    var abilities: [String]?
    var stats:[(String,String)]?
    var weight:String?
    var moves:[String]?
    var types:[String]?
    var baseExperience:String?
    var height:String?
    var effortValues:[(String,String)]?
    var habitat:[String]?
    var eggGroup:[String]?
    var generation:[String]?
    var pokedexEntry:String?
    var shape:[String]?
    var growthRate:[String]?
    var evolvesFrom:[String]?
    var baseHappiness:String?
    var hatchCounter:String?
    var genderRate:String?
    var captureRate:String?
    var color:[String]?
    
    func formatDetails()->[[String]]{
        var output:[[String]] = []
        //construct the output
        output.append([(pokedexEntry ?? "Not Found")])
        output.append( types ?? ["Not Found"])
        output.append( abilities ?? ["Not Found"])
        output.append( evolvesFrom ?? ["Not Found"])
        output.append( [(height ?? "Not Found")])
        output.append([(weight ?? "Not Found")])
        output.append(eggGroup ?? ["Not Found"])
        output.append([(captureRate ?? "Not Found")])
        output.append([(genderRate ?? "Not Found")])
        output.append( growthRate ?? ["Not Found"])
        output.append( [(baseHappiness ?? "Not Found")])
        output.append(shape ?? ["Not Found"])
        output.append(color ?? ["Not Found"])
        output.append(habitat ?? ["Not Found"])
        output.append(generation ?? ["Not Found"])
        output.append([(baseExperience ?? "Not Found")])
        //output.append(effortValues.map{$0.0 + ": " + $0.1} ?? ["Not Found"])//<==not working
        //output.append(stats.map{$0.0 + ": " + $0.1} ?? ["Not Found"])//<==not working
        output.append(moves ?? ["Not Found"])
        return output
        //reduce seems to have slightly changed with swift 4.  stats and ev yield dont work there
    }

    static func getSectionHeaders(section: Int)->String?{
        let output:String?
        switch section{
        case 2:
            output = "Pokedex Entry"
        case 3:
            output = "Types"
        case 4:
            output = "Abilities"
        case 5:
            output = "Prior Evolution"
        case 6:
            output = "Height"
        case 7:
            output = "Weight"
        case 8:
            output = "Egg Group"
        case 9:
            output = "Capture Rate"
        case 10:
            output = "Gender Rate"
        case 11:
            output = "Growth Rate"
        case 12:
            output = "Base Happiness"
        case 13:
            output = "Shape"
        case 14:
            output = "Color"
        case 15:
            output = "Habitat"
        case 16:
            output = "Generation"
        case 17:
            output = "Base Experience"
        case 18://<==insert missing stuff here
            output = "Moves"
        default:
            output = nil
        }
        return output
    }
    
    static func getNumberOfRowsInSection(data: [[String]], section: Int)->Int{
        let output:Int
        switch section{
        case 0...1, 5:
            output = 1
        case 3,4,8:
            output = (data[section-2].count)/2
        case 11, 13...16:
            output = data[section-2].count - 1
        default:
            output = data[section-2].count
        }
        return output
    }
    

}
