//
//  ImprovedNetworking.swift
//  Pokedex
//
//  Created by Godohaldo Perez on 9/13/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class ImprovedNetworking{
    static func callNetwork(type:NetworkCall,completion:@escaping (Any?,NetworkError?)->()){
        switch type{
        case .getImage:
            downloadImage(url: type.getUrl(), completion: completion)
        case .getPokemonList:
            downloadPokemonList(url: type.getUrl(), completion: completion)
        case .getDetails:
            downloadDetails(url: type.getUrl(), completion: completion)
        case .getSecondaryPokemonList:
            downloadNewList(url: type.getUrl(), completion: completion)
        case .getPokemonListFirstChunk:
            downloadPokemonListFirstChunk(url: type.getUrl(), completion: completion)
        case .getPokemonListNext20:
            downloadPokemonListNext20(url: type.getUrl(), completion: completion)
        }
    }
    
    private static func downloadPokemonListFirstChunk(url:String,completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else {
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            do{
                let jsonObject = try JSONSerialization.jsonObject(with: data)
                guard let dictionary = jsonObject as? [String:Any] else{
                    let networkError = NetworkError.apiFailedConvertingJSONToDictionary
                    completion(nil,networkError)
                    return
                }
                guard let results = dictionary["results"] as? [[String:String]] else{
                    let networkError = NetworkError.apiFailedParsingDictionaries
                    completion(nil,networkError)
                    return
                }
                guard let next = dictionary["next"] as? String else{
                    let networkError = NetworkError.apiFailedParsingDictionaries
                    completion(nil,networkError)
                    return
                }
                let pokemonList = results.flatMap{
                    Pokemon(name: $0["name"]?.uppercased() ?? "MissingNo.", number: getNumber(url:  $0["url"] ?? "MissingURL"))
                }
                completion((pokemonList,next),nil)
            }catch let error{
                let networkError = NetworkError.apiFailedParsingJSON(error.localizedDescription)
                completion(nil,networkError)
            }
            
        }
        task.resume()
    }
    
    private static func downloadPokemonListNext20(url:String,completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else {
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            do{
                let jsonObject = try JSONSerialization.jsonObject(with: data)
                guard let dictionary = jsonObject as? [String:Any] else{
                    let networkError = NetworkError.apiFailedConvertingJSONToDictionary
                    completion(nil,networkError)
                    return
                }
                guard let results = dictionary["results"] as? [[String:String]] else{
                    let networkError = NetworkError.apiFailedParsingDictionaries
                    completion(nil,networkError)
                    return
                }
                guard let next = dictionary["next"] as? String else{
                    let networkError = NetworkError.apiFailedParsingDictionaries
                    completion(nil,networkError)
                    return
                }
                let pokemonList = results.flatMap{
                    Pokemon(name: $0["name"]?.uppercased() ?? "MissingNo.", number: getNumber(url:  $0["url"] ?? "MissingURL"))
                }
                
                if pokemonList[pokemonList.count-1].pokemonNumber > 151{
                    let output:([Pokemon],String?) = (pokemonList.filter{$0.pokemonNumber<=151},nil)
                    completion(output, nil)
                }else{
                    completion((pokemonList, next), nil)
                }
            }catch let error{
                let networkError = NetworkError.apiFailedParsingJSON(error.localizedDescription)
                completion(nil,networkError)
            }
            
        }
        task.resume()
    }
    
    private static func downloadImage(url:String,completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else{
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            guard let image = UIImage(data: data) else{
                let networkError = NetworkError.dataIsNotAnImage
                completion(nil,networkError)
                return
            }
            
            completion(image,nil)
        }
        task.resume()
    }

    private static func downloadPokemonList(url:String,completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else {
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            do{
                let jsonObject = try JSONSerialization.jsonObject(with: data)
                guard let dictionary = jsonObject as? [String:Any] else{
                    let networkError = NetworkError.apiFailedConvertingJSONToDictionary
                    completion(nil,networkError)
                    return
                }
                guard let results = dictionary["results"] as? [[String:String]] else{
                    let networkError = NetworkError.apiFailedParsingDictionaries
                    completion(nil,networkError)
                    return
                }
                let pokemonList = results.flatMap{
                    Pokemon(name: $0["name"]?.uppercased() ?? "MissingNo.", number: getNumber(url:  $0["url"] ?? "MissingURL"))
                }
                completion(pokemonList,nil)
            }catch let error{
                let networkError = NetworkError.apiFailedParsingJSON(error.localizedDescription)
                completion(nil,networkError)
            }
            
        }
        task.resume()
    }
    
    private static func downloadDetails(url:String,completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url) else {return}
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else{
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            do{
                let jsonObject = try JSONSerialization.jsonObject(with: data)
                guard let dictionary = jsonObject as? [String:Any] else{
                    let networkError = NetworkError.apiFailedConvertingJSONToDictionary
                    completion(nil,networkError)
                    return
                }
                
                //get url for additional details
                guard let species = dictionary["species"] as? [String:String] else{
                    let networkError = NetworkError.apiFoundNoSpeciesUrl
                    completion(nil,networkError)
                    return
                }
                guard let url = species["url"] else{
                    let networkError = NetworkError.apiFoundNoSpeciesUrl
                    completion(nil,networkError)
                    return
                }
                downloadAdditionalDetails(url: url, detailsDictionary: dictionary,completion: completion)
            }catch let error{
                let networkError = NetworkError.apiFailedParsingJSON(error.localizedDescription)
                completion(nil,networkError)
            }

            //completion(data,nil)
        }
        task.resume()
    }
    private static func downloadAdditionalDetails(url:String,detailsDictionary:[String:Any],completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url) else {
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return}
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else{
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            do{
                let jsonObject = try JSONSerialization.jsonObject(with: data)
                guard let dictionary = jsonObject as? [String:Any] else{
                    let networkError = NetworkError.apiFailedConvertingJSONToDictionary
                    completion(nil,networkError)
                    return
                }
                
                var details = PokemonDetails()
                
                //get details from dictionary
                //get capture rate
                if let captureRate = dictionary["capture_rate"] as? Int{
                    details.captureRate = String(captureRate)
                }
                //get base happiness
                if let baseHappines = dictionary["base_happiness"] as? Int{
                    details.baseHappiness = String(baseHappines)
                }
                //get hatch counter
                if let hatchCounter = dictionary["hatch_counter"] as? Int{
                    details.hatchCounter = String(hatchCounter)
                }
                //get evolves from
                if let evolvesFrom = dictionary["evolves_from_species"] as? [String:String]{
                    details.evolvesFrom = [evolvesFrom["name"] ?? "Not Found", String(getNumber(url:  evolvesFrom["url"] ?? "MissingURL"))]
                }else{
                    details.evolvesFrom = ["No known prior evolution"]
                }
                //get gender rate
                if let genderRate = dictionary["gender_rate"] as? Double{
                    details.genderRate = "\((1 - (genderRate/8))*100)% male"
                }
                //get habitat
                if let habitat = dictionary["habitat"] as? [String:String]{
                    details.habitat = [habitat["name"] ?? "Not Found",habitat["url"] ?? "Not Found"]
                    
                }
                //get color
                if let color = dictionary["color"] as? [String:String]{
                    details.color = [color["name"] ?? "Not Found",color["url"] ?? "Not Found"]
                }
                //get generation
                if let generation = dictionary["generation"] as? [String:String]{
                    details.generation = [generation["name"] ?? "Not Found",generation["url"] ?? "Not Found"]
                }
                //get growth rate
                if let growthRate = dictionary["growth_rate"] as? [String:String]{
                    details.growthRate = [growthRate["name"] ?? "Not Found",growthRate["url"] ?? "Not Found"]
                }
                //get shape
                if let shape = dictionary["shape"] as? [String:String]{
                    details.shape = [shape["name"] ?? "Not Found",shape["url"] ?? "Not Found"]
                }
                //get egg group
                if let eggGroup = dictionary["egg_groups"] as? [[String:String]]{
                    var output:[String] = []
                    for element in eggGroup{
                        output += [element["name"] ?? "Not Found"]
                        output += [element["url"] ?? "Not Found"]
                    }
                    details.eggGroup = output
                    /*
                    details.eggGroup = eggGroup.flatMap{
                        $0["name"]
                    }*/
                }
                //get pokedex entry
                if let flavorTextEntries = dictionary["flavor_text_entries"] as? [[String:Any]]{
                    let filtered = flavorTextEntries.filter{
                        let version = $0["version"] as? [String:String]
                        let language = $0["language"] as? [String:String]
                        return version?["name"] == "omega-ruby" && language?["name"] == "en" ? true : false
                        
                    }
                    if filtered.count > 0{//not sure this is necessary
                        details.pokedexEntry = filtered[0]["flavor_text"] as? String
                    }
                }
               
                //parse details from the other dictionary
                //get detais from the dictionary
                //get height
                if let height = detailsDictionary["height"] as? Double {
                    details.height = "\(height/10) m"
                }
                //get weight
                if let weight = detailsDictionary["weight"] as? Double {
                    details.weight = "\(weight/10) kg"
                }
                //get base experience
                if let baseExperience = detailsDictionary["base_experience"] as? Int {
                    details.baseExperience = String(baseExperience)
                }
                //get abilities
                if let abilities = detailsDictionary["abilities"] as? [[String:Any]]{
                    /*
                    let slot = abilities.flatMap{
                        $0["slot"] as? Int
                    }*/
                    let ability = abilities.flatMap{
                        $0["ability"] as? [String:String]
                    }
                    var output:[String] = []
                    for element in ability{
                        output += [element["name"] ?? "Not Found"]
                        output += [element["url"] ?? "Not Found"]
                    }
                    details.abilities = output
                    /*
                    let abilityNames = ability.flatMap{
                        $0["name"]
                    }*/
                    //details.abilities = Array(zip(abilityNames, slot)).sorted{$0.1 < $1.1}.flatMap{$0.0}
                }
                //get base stats and effort values
                if let stats = detailsDictionary["stats"] as? [[String:Any]]{
                    let stat = stats.flatMap{
                        $0["stat"] as? [String:String]
                    }
                    let statNames = stat.flatMap{
                        $0["name"]
                    }
                    let baseStat = stats.flatMap{
                        $0["base_stat"] as? Int
                    }
                    let effort = stats.flatMap{
                        $0["effort"] as? Int
                    }
                    details.stats = Array(zip(statNames, baseStat)).map{($0.0,String($0.1))}
                    details.effortValues = Array(zip(statNames, effort)).filter{$0.1 != 0}.map{($0.0,String($0.1))}
                }
                //get types
                if let types = detailsDictionary["types"] as? [[String:Any]]{
                    /*let slot = types.flatMap{
                        $0["slot"] as? Int
                    }*/
                    let type = types.flatMap{
                        $0["type"] as? [String:String]
                    }
                    var output:[String] = []
                    for element in type{
                        output += [element["name"] ?? "Not Found"]
                        output += [element["url"] ?? "Not Found"]
                    }
                    details.types = output
                    /*
                    let typeNames = type.flatMap{
                        $0["name"]
                    }*/
                    //details.types = Array(zip(typeNames, slot)).sorted{$0.1 < $1.1}.flatMap{$0.0}
                }
                //get movelist
                if let moves = detailsDictionary["moves"] as? [[String:Any]]{
                    let move = moves.flatMap{
                        $0["move"] as? [String:String]
                    }
                    let moveName = move.flatMap{
                        $0["name"]
                    }
                    details.moves = moveName
                }
                
                //completion(details.printDetails(),nil)
                completion(details.formatDetails(),nil)
                
            }catch let error{
                let networkError = NetworkError.apiFailedParsingJSON(error.localizedDescription)
                completion(nil,networkError)
            }

        }
        task.resume()
    }
    private static func downloadNewList(url:String,completion:@escaping(Any?,NetworkError?)->()){
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else {
                let networkError = NetworkError.apiRespondedWithMalformedData
                completion(nil,networkError)
                return
            }
            do{
                let jsonObject = try JSONSerialization.jsonObject(with: data)
                guard let dictionary = jsonObject as? [String:Any] else{
                    let networkError = NetworkError.apiFailedConvertingJSONToDictionary
                    completion(nil,networkError)
                    return
                }
                if let results = dictionary["pokemon_species"] as? [[String:String]]{
                    let pokemonList = results.flatMap{
                        Pokemon(name: $0["name"]?.uppercased() ?? "MissingNo.", number: getNumber(url:  $0["url"] ?? "MissingURL"))
                    }
                    completion(pokemonList.filter{$0.pokemonNumber<=151},nil)
                }else if let pokemon = dictionary["pokemon"] as? [[String:Any]]{
                    let pokemon2 = pokemon.flatMap{
                        $0["pokemon"] as? [String:String]
                    }
                    let pokemonList = pokemon2.flatMap{
                        Pokemon(name: $0["name"]?.uppercased() ?? "MissingNo.", number: getNumber(url:  $0["url"] ?? "MissingURL"))
                    }
                    completion(pokemonList.filter{$0.pokemonNumber<=151},nil)
                }else{
                    let networkError = NetworkError.apiFailedParsingDictionaries
                    completion(nil,networkError)
                    return
                }
            }catch let error{
                let networkError = NetworkError.apiFailedParsingJSON(error.localizedDescription)
                completion(nil,networkError)
            }
        }
        task.resume()
    }
    private static func getNumber(url:String)->Int{
        let pieces = url.components(separatedBy: "/")
        guard pieces.count >= 2 else {return 0}
        return Int(pieces[pieces.count - 2]) ?? 0
        
        
    }
}
